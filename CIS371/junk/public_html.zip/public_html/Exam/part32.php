<html>
<head>
    <title>part3</title>

	
		<h1>Part 3</h1>

	<fieldset style="display: inline-block;">
		<form id="form1"  >
			<?php
				$num = 3;
				$value = 6;
				$num = $_GET['num'];
				for($i=0; $i<$num; $i++){
            		echo '<input type="number" id = "'.$i.'"style="margin:2px"/><br/><br/>';
				}
			?>
             </form>
	<?php
			$max=0;
			$min=0;
			$avg=0;
			
			echo 'Max value: <input type ="text" disabled  id="max"name="Max value: " value="'.$max.'"><br>';
			echo 'Min value: <input type ="text" disabled id="min"name="Mix value: " value="'.$min.'"><br>';
			echo 'Average:   <input type ="text" disabled id="avg"name="Max value: " value="'.$avg.'">';
?>
    </fieldset>	
<button onclick="myFunction()">Try it</button>
<p id="demo"></p>
<script>

	function myFunction(){
		var x = document.getElementById("form1");
		for (c = 0; c < x.length ;c++) {
		document.getElementById(c).style.backgroundColor="";
}
		
		
    var text = [];
    var i;
     for (i = 0; i < x.length ;i++) {
		text.push(x.elements[i].value);
		
    }
	Math.max(text)
	var amax = Math.max.apply(Math,text);
	
	//alert(amax);
	var a = text.indexOf(''+amax);
	//alert(a+" index a");	
	document.getElementById(a).style.backgroundColor = "#ffff80";
	document.getElementById("max").value= amax;
	
	var amin = Math.min.apply(Math,text);
	//alert(amin);
	var b = text.indexOf(''+amin);
	//alert(b+" index b");	
	document.getElementById(b).style.backgroundColor = "#66c2ff";
	document.getElementById("min").value= amin;
	var count = 0;
   for(var r=0, n= text.length; r < n; r++) 
   { 
      count += parseInt(text[r]); 
   }
	var avg = count/n;
	//alert(count);
	//alert(text.length);
	document.getElementById("avg").value= avg;
    document.getElementById("demo").innerHTML = text;
	//alert(avg);
	return false;
}

</script>
 
	 
				
</head>
<body>

</body>
</html>

