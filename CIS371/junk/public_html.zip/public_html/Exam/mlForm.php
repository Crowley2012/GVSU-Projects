<!-- Sean Crowley -->

<html>
<head>
    <title>MadLibs for CS 371 Final</title>
    <script type="text/javascript" src="ml.js"></script>
</head>
<body>

	<h1>My Mad Libs</h1>

	<form action="mlForm.php" name="form1" id="theForm" action="form-handler" method="post" onsubmit="return validateForm();">

		<?php
			ini_set('display_errors', 1);
			ini_set('display_startup_errors', 1);
			error_reporting(E_ALL);

			$xmlDoc = new DomDocument();
			$xmlDoc->load("story1.html");
			$root = $xmlDoc->documentElement;
			$span = $xmlDoc->getElementsByTagName('span');

			$i = 0;
			foreach ($span as $line) {
				if($line->getAttribute('class') == 'fillin'){
            		echo '<code>', $line->nodeValue, '<input type="text" name="', $i, '" style="margin:2px"/><br/>';
				}
			}
		?>

		<input type="submit" name="buttonSubmit" value="Submit"/>
	</form>

	<div id="story">
		<?php echo $xmlDoc->saveHTML(); ?>
	</div>

</body>
</html>
