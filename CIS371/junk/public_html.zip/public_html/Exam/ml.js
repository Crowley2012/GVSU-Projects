//Sean Crowley

window.onload = function () {

	var fillin = document.getElementsByClassName("fillin");

	for(i=0; i<fillin.length; i++){
		fillin[i].style.color = 'red';
	}

};

function validateForm() {

	var fields = document.getElementsByClassName("fillin").length;
	var fillin = document.getElementsByClassName("fillin");

	for(i=0; i<fields; i++){
		if(document.forms["form1"][i].value == ""){
			document.forms["form1"][i].style.backgroundColor = "red";
			fillin[i].style.color = 'red';
		}else{
			document.forms["form1"][i].style.backgroundColor = "white";
			fillin[i].innerHTML = document.forms["form1"][i].value;
			fillin[i].style.color = 'blue';
		}
	}

	return false;
}
