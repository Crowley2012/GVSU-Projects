<?php
function connect(){
	$servername = "127.0.0.1";
	$username = "crowleys";
	$password = "crowleys";
	$dbname = "crowleys";
	$conn = new mysqli($servername, $username, $password, $dbname);

	if ($conn->connect_error) {
		echo "ERROR : Connected unsuccessfully<br /><br />";
		die("Connection failed: " . $conn->connect_error);
	} 

	return $conn;
}

function createTableUsers(){
	$sql = "create table if not exists events(id int(30) NOT NULL AUTO_INCREMENT, title varchar(30), date varchar(30), startTime varchar(30), stopTime varchar(30), description varchar(30), PRIMARY KEY (id))";
	$conn = connect();
	$result = $conn->query($sql);
}

function rebuildUsers(){
	$sql = "drop table events";
	$conn = connect();
	$result = $conn->query($sql);

	createTableUsers();
	addDummyEvents();
}

function insert($title, $date, $startTime, $stopTime, $description){
	$conn = connect();
	$sql = "insert into events(title, date, startTime, stopTime, description) values ('$title', '$date', '$startTime', '$stopTime', '$description')";
	$result = $conn->query($sql);
}

function addDummyEvents(){
	insert("Game", "6/20/2016", "1:00pm", "5:00pm", "Baseball");
	insert("Dance", "6/21/2016", "3:00pm", "4:00pm", "School Dance");
	insert("Car", "6/25/2016", "11:20am", "2:40pm", "Clean Car");
	insert("Food", "7/5/2016", "11:00am", "1:00pm", "Eat Food");
	insert("School", "8/1/2017", "2:30pm", "4:45pm", "Learn");
}

function getAll(){
	$sql = "SELECT * FROM events";
	$conn = connect();
	$result = $conn->query($sql);

	echo "<center><table id='sqltable' width='50%'>";
	echo "<tr><th>ID</th><th>Title</th><th>Date</th><th>Start Time</th><th>Stop Time</th><th>Description</th></tr>";

	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			echo "<tr><td>", $row["id"], "</td><td>", $row["title"], "</td><td>", $row["date"],  "</td><td>", $row["startTime"], "</td><td>", $row["stopTime"], "</td><td>", $row["description"], "</td></tr>";	
		}
	} else {
		echo "0 results";
	}

	echo "</table></center>";

	$conn->close();
}
?>
