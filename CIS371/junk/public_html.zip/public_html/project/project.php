<?php
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);

	include 'projectfunctions.php';
	include 'projectsql.php';

	$color = "white";

	if(isset($_COOKIE['color'])){
    	$color = $_COOKIE['color'];
	}

	if(isset($_GET['color'])){
    	$color = $_GET['color'];
    	setcookie('color', $color, time() + 10);
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html;charset=iso-8859-1"/>
	<link rel="stylesheet" href="project.css" type="text/css"/>
	<title>Assignment 15</title>
</head>
<body>
	<center>
		<h2>Project</h2>
	</center>

	<form method="post">
		<input class="prev" height="10%" width="10%" type="image" src="arrow.png" name="previous" value="Previous"/>

		<?php 
			setup();
			rebuildUsers();
		?>

		<input class="next" height="10%" width="10%" type="image" src="arrow.png" name="next" value="Next"/>
	</form>
	<?php 
		getAll();
	?>
</body>
</html>
