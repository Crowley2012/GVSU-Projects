<?php
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);

	session_start();

	$loggedIn = false;

	if(isset($_SESSION['email']) && isset($_SESSION['name']) && isset($_SESSION['admin'])){
		$email=$_SESSION['email'];
		$name=$_SESSION['name'];
		$admin=$_SESSION['admin'];
		$loggedIn = true;
	}

	include 'projectfunctions.php';
	include 'projectsql.php';

	//rebuildSongs();
	//rebuildVotes();
	//rebuildUsers();

	//printAllUsers();
	//printAllSongs();
	//printAllVotes();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html;charset=iso-8859-1"/>
	<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
	<link rel="stylesheet" href="project.css" type="text/css"/>
    <script type="text/javascript" src="project.js"></script>

	<title>Sean Crowley : Project</title>
</head>
<body>

	<div id="sidebar">
		<center>
		<h1 id="voting">Voting</h1>
		<?php
			if(isset($email)){
				displayAllSongsUser($email);
			}else{
				displayAllSongs();
			}
		?>
		</center>
	</div>

	<div id="userInfo" align="center">
		<?php
			if($loggedIn){
				echo "Welcome back ", $name, "!<br/><br/>";
			}

			echo '<form name="logoutForm" method="post">';

			if($loggedIn){
				echo '<input type="submit" name="buttonLogout" value="Logout" class="loginField" id="logoutButton"/>';
			}else{
				echo '<input type="submit" name="buttonLogin" value="Login" class="loginField" id="logoutButton"/>';
			}

			echo '</form>';

			if(isset($_POST['buttonLogout'])){
				session_destroy();
				header("Location: project.php");
			}

			if(isset($_POST['buttonLogin'])){
				session_destroy();
				header("Location: projectlogin.php");
			}
		?>
	</div>
</body>
</html>
