<html>
<head>
	<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
	<link rel="stylesheet" href="project.css" type="text/css"/>
    <title>Login</title>
</head>
<body>

	<h1 id="loginTitle" align="center">Login</id>

	<div id="loginInfo">
		<form action="projectlogin.php" method="post" align="center">
		    <input class="loginField loginInput" type="text" name="email" placeholder="Email"/><br/>

		    <input class="loginField loginInput" type="password" name="password" placeholder="Password"/><br/>

		    <input class="loginField" id="loginButton" type="submit" name="buttonSubmit" value="Submit"/>
		</form>
	</div>

	<?php
		include 'projectsql.php';

	    $name=$_POST['email']; 
		$password=$_POST['password']; 

		login($name, $password);
	?>
</body>
</html>
