window.onload = function () {
	addClick();
};


function addClick(){
	var li = document.getElementsByClassName("voteElement");

	for (var i = 0; i < li.length; i++) {
		li[i].addEventListener("click", vote);
	}
}

function vote(event){
	if(this.style.backgroundColor != 'green'){
		this.style.backgroundColor = 'green';
	}else{
		this.style.backgroundColor = 'rgba(255, 255, 255, 0.8)';
	}
}
