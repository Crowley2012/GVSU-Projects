<html>
<head>
    <title>Midterm Coding</title>
</head>
<body>
	<h1>Add The Primes</h1>
	<p>Select which primes you want to add</p>

	<?php
		$number = $_COOKIE['number'];
		$width = $_COOKIE['width'];

		if($number == null){
			$number = $_GET['number'];
			setcookie('number', $number, time() + 1);
		}

		if($width == null){
			$width = $_GET['width'];
			setcookie('width', $width, time() + 1);
		}

		echo "<p>number : ", $number, "</p>";
		echo "<p>width : ", $width, "</p>";

		function is_prime($n){
			for($i = 2; $i * $i <= $n; $i++){
				if($n % $i == 0){
					return false;
				}
			}
			return true;
		}

		echo "<form action='midterm.php' method='post'>";
		echo "<table border='1'>";

		$items = 0;

		for($j = 2; $j < $number; $j++){
			if($items % $width == 0){
				echo "<tr>";
			}

			if(is_prime($j)){
					//echo "<p>number : ", $items % $width, "</p>";

				echo "<td id='post'><input type='checkbox' name='check_list[]' value='", $j, "'>", $j, "</td>";

				$items ++;

				if($items % $width == 0){
					echo "</tr>";
				}
			}
		}
		echo '<input type="submit" name="buttonSubmit" value="Submit"/>';

		echo "</table>";
		echo "</form>";

		$sum = 0;

		foreach($_POST['check_list'] as $selected){
			$sum += $selected;
		}

		echo $sum;
	?>

</body>
</html>
