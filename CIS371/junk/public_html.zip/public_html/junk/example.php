
<!-- This file demonstrates
    (1) How to set up a simple HTML form
    (2) How to use PHP to access the data
-->
<?php error_reporting(E_ALL); ?>
<html>
<head>
    <title>Form Demo</title>
    <style type="text/css">
        #get, #post {
            vertical-align: top;
        }

    </style>
</head>
<body>

<h1>Form Demo</h1>


<table>
    <tr>
        <td id="post">

            <fieldset>
                <legend>POST form</legend>
                <form action="formDemo.php" method="post">
                    "text" type input named <code>theFirstPost</code>
                    <input type="text" name="theFirstPost" value="Value for first POST input"/><br/>
                    "text" type input named <code>theSecondPost</code>
                    <input type="text" name="theSecondPost" value="Value for Post #2"/><br/>
                    Radio buttons named "interest":
                    Cool <input type="radio" name="interest" value="itsCool" checked="checked"/>
                    OK <input type="radio" name="interest" value="itsOK">
                    Boring <input type="radio" name="interest" value="itsBoring"></br>

                    Radio buttons named "bestState":
                    Georgia <input type="radio" name="bestState" value="GA"/>
                    Michigan <input type="radio" name="bestState" value="MI">
                    California <input type="radio" name="bestState" value="CA" checked="checked"></br>

                    Checkboxes named "IScourses":
                    260 <input type="checkbox" name="IScourses[]" value="cis260" checked="checked"/>
                    333 <input type="checkbox" name="IScourses[]" value="cis333"/>
                    463 <input type="checkbox" name="IScourses[]" value="cis463"/><br/>

                    <input type="submit" name="postSubmit1" value="Submit Button 1"/>
                    <input type="submit" name="postSubmit2" value="Submit Button 2"/>

                </form>
            </fieldset>

            <table>
                <tr>
                    <th colspan=2>Contents of <code>$_POST</code></th>
                </tr>
                <tr>
                    <th>Key</th>
                    <th>Value</th>
                </tr>
                <?php
                foreach ($_POST as $key => $value) {
                    $printMe = $value;
                    if (is_array($value)) {
                        $printMe = "[" . implode($value, ", ") . "]";
                    }
                    echo "<tr><td>$key</td><td>$printMe</td></tr>\n";
                }
                ?>
            </table>


        </td>
</table>

<?php

$fp = fopen("php://input", 'r+');
echo stream_get_contents($fp);
?>

<hr>
<?php var_dump($_SERVER); ?>


</body>
</html>
